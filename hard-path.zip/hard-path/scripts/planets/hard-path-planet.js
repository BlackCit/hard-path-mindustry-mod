// scripts/planets/kryptum.js

// Находим генератор Серпуло
const base = Vars.content.getByName(ContentType.planet, "serpulo").generator;

// Создаём наш генератор
const kryptumGen = extend(base.constructor, base, {});

// Регистрируем под именем, которое указали в kryptum.json
PlanetGenerator.register("kryptum-gen", () => kryptumGen);
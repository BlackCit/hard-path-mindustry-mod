// scripts/tech_tree.js

// Получаем планету
const kryptum = Vars.content.planet("kryptum");

// Получаем предметы
const kryptumiy = Vars.content.item("kryptumiy");
const entalit = Vars.content.item("entalit");

// Получаем блоки
const drillKryptumiy = Vars.content.block("drill-kryptumiy");
const conveyor = Vars.content.block("Conveyor");
const junction = Vars.content.block("Junction");
const bridge = Vars.content.block("Bridge");
const waterGenerator = Vars.content.block("water-generator");
const dobleTurret = Vars.content.block("doble-turret");

// Создаём корневое древо
kryptum.techTree = TechTree.nodeRoot("Криптум: Путь", kryptum, () => {

    // Ветка 1: Добыча криптумия
    TechTree.node(kryptumiy, ItemStack.with(Items.copper, 100), () => {

        // Гидравлический бур (открывается после криптумия)
        TechTree.node(drillKryptumiy, ItemStack.with(Items.copper, 200, kryptumiy, 50), () => {

            // Ветка логистики (открывается после бура)
            TechTree.node(conveyor, ItemStack.with(Items.copper, 50), () => {

                // Перекрёсток
                TechTree.node(junction, ItemStack.with(Items.copper, 80), () => {

                    // Мост
                    TechTree.node(bridge, ItemStack.with(Items.copper, 120), () => {});
                });
            });

            // Ветка энергии (параллельно логистике)
            TechTree.node(waterGenerator, ItemStack.with(Items.copper, 150, kryptumiy, 80), () => {

                // Турель (нужна вода для охлаждения)
                TechTree.node(dobleTurret, ItemStack.with(Items.copper, 300, Items.lead, 150, kryptumiy, 100), () => {});
            });
        });

        // Ветка энталита (параллельно буру)
        TechTree.node(entalit, ItemStack.with(Items.copper, 150, kryptumiy, 50), () => {
            // Пока тут пусто, но сюда можно будет добавить плавильню для энталита
        });
    });
});